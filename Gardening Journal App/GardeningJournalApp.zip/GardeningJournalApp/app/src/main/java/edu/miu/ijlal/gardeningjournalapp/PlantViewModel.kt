package edu.miu.ijlal.gardeningjournalapp

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class PlantViewModel(private val repository: PlantRepository) : ViewModel() {

    val allPlants: LiveData<List<Plant>> = repository.allPlants

    fun delete(plant: Plant) = viewModelScope.launch {
        repository.delete(plant)
    }

    fun insert(plant: Plant) = viewModelScope.launch {
        repository.insert(plant)
    }
}
