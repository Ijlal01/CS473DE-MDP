package edu.miu.ijlal.gardeningjournalapp

import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PlantRepository(private val plantDao: PlantDao) {

    val allPlants: LiveData<List<Plant>> = plantDao.getAllPlants()

    @WorkerThread
    suspend fun insert(plant: Plant) {
        withContext(Dispatchers.IO) {
            plantDao.insert(plant)
        }
    }

    @WorkerThread
    suspend fun delete(plant: Plant) {
        plantDao.delete(plant)
    }
}
